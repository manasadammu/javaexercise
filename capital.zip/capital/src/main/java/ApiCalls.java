import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;

public class ApiCalls {

    String byNameUrl = "https://restcountries.eu/rest/v2/name/";

    String byCodeUrl = "https://restcountries.eu/rest/v2/alpha/";

    String byFullNameUrl = "https://restcountries.eu/rest/v2/name/{fullName}?fullText=true";

    //String capitalCityUrl = "https://restcountries.eu/rest/v2/capital/";

    public String getRestApiResponse(String userInput) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        userInput = StringUtils.lowerCase(userInput);

        CreateHttpRequest createHttpRequest = new CreateHttpRequest();
        String apiResponse = "";
        String capitalCity= "";
        String response ="";
            if(StringUtils.isNotBlank(userInput)) {
                if (userInput.length() == 2 || userInput.length() == 3) {
                  try {
                      apiResponse = createHttpRequest.createHttpRequest(byCodeUrl + userInput, "GET");
                      if(!StringUtils.isBlank(apiResponse)){
                          Country country = objectMapper.readValue(apiResponse, Country.class);
                          capitalCity = country.capital;
                          response = "\n Great, CAPITAL CITY of " + userInput.toUpperCase() + " is : " + capitalCity;
                          return response;
                      }
                  }catch (Exception e){}
                } else if(StringUtils.isBlank(apiResponse)){
                    try {
                        apiResponse = createHttpRequest.createHttpRequest(byNameUrl + userInput, "GET");

                    }catch (Exception e){}
                }
                else if (StringUtils.isBlank(apiResponse)) {
                    try {
                        byFullNameUrl.replace("{fullName}", userInput);
                        apiResponse = createHttpRequest.createHttpRequest(byFullNameUrl, "GET");
                    }catch (Exception e){}
                }

            }
            if(apiResponse.isEmpty()){
                response = "\n Invalid input, please enter a valid country name or code";
                return response;
            }



        if(StringUtils.isNoneBlank(apiResponse)){
            Country[] country = objectMapper.readValue(apiResponse, Country[].class);
            capitalCity = country[0].capital;
            response = "\n Great, CAPITAL CITY of " + userInput.toUpperCase() + " is : " + capitalCity;
        }
        return response;
    }

}
