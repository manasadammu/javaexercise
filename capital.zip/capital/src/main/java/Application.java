import com.mashape.unirest.http.exceptions.UnirestException;
import org.apache.commons.lang3.StringUtils;
import java.io.IOException;
import java.util.Scanner;

public class Application {
    public static void main(String args[]) throws IOException, UnirestException {
        String prompt = "Please enter [NATIVENAME or PARTIALNAME or FULLNAME or CODE] "
            + "of country to get the Capital City. Or else type EXIT to Quit)";
        System.out.println("Welcome User, "+prompt);
        String userInput = "ENTRY";
        while(!userInput.equalsIgnoreCase("EXIT")) {
            Scanner in = new Scanner(System.in);
            userInput = in.nextLine();
            if(StringUtils.equalsIgnoreCase(userInput, "EXIT")){
                System.exit(0);
            }
            else {
                System.out.println("Please hold on for few seconds");
                ApiCalls apiCalls = new ApiCalls();
                String capitalCity = apiCalls.getRestApiResponse(userInput);
                System.out.println(capitalCity);
                System.out.println( " \n To fetch again , "+prompt);
            }
        }
    }
}
