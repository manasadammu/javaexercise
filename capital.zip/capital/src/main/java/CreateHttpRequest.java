import org.apache.commons.io.IOUtils;
import org.omg.CORBA.SystemException;
import javax.net.ssl.HttpsURLConnection;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.URL;

public class CreateHttpRequest {

    public static String createHttpRequest(String restApi, String method) throws SystemException, IOException {

        URL url = new URL(restApi);
        String response = "";
        try {
            HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
            connection.setRequestMethod(method);
            connection.setDoOutput(true);
            DataInputStream res = new DataInputStream(connection.getInputStream());
            response = IOUtils.toString(res);
            //System.out.println("URL "+restApi);
            //System.out.println("response : "+response);
        }
        catch (Exception e){
            //e.printStackTrace();
        }
        return response;

    }

}
