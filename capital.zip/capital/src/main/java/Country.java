import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
//@JsonFormat(shape=JsonFormat.Shape.ARRAY)
public class Country {

    @JsonProperty("name")
    public String name;

    @JsonProperty("topLevelDomain")
    public List<String> topLevelDomain;

    @JsonProperty("alpha2Code")
    public String alpha2Code;

    @JsonProperty("alpha3Code")
    public String alpha3Code;

    @JsonProperty("callingCodes")
    public List<String> callingCodes;

    @JsonProperty("capital")
    public String capital;

    @JsonProperty("altSpellings")
    public List<String> altSpellings;

    @JsonProperty("region")
    public String region;

    @JsonProperty("subregion")
    public String subregion;

    @JsonProperty("population")
    public long population;

    @JsonProperty("latlong")
    public List<Integer> latlong;

    @JsonProperty("demonym")
    public String demonym;

    @JsonProperty("area")
    public long area;

    @JsonProperty("gini")
    public float gini;

    @JsonProperty("timezones")
    public List<String> timezones;

    @JsonProperty("borders")
    public List<String> borders;

    @JsonProperty("nativeName")
    public String nativeName;

    @JsonProperty("numericCode")
    public String numericCode;

    @JsonProperty("currencies")
    public List<Currency> currencies;

    @JsonProperty("languages")
    public List<Language> languages;

    @JsonProperty("translations")
    public Translations translations;

    @JsonProperty("flag")
    public String flag;

    @JsonProperty("regionalBlocs")
    public List<RegionalBlock> regionalBlocs;

    @JsonProperty("cioc")
    public String cioc;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getTopLevelDomain() {
        return topLevelDomain;
    }

    public void setTopLevelDomain(List<String> topLevelDomain) {
        this.topLevelDomain = topLevelDomain;
    }

    public String getAlpha2Code() {
        return alpha2Code;
    }

    public void setAlpha2Code(String alpha2Code) {
        this.alpha2Code = alpha2Code;
    }

    public String getAlpha3Code() {
        return alpha3Code;
    }

    public void setAlpha3Code(String alpha3Code) {
        this.alpha3Code = alpha3Code;
    }

    public List<String> getCallingCodes() {
        return callingCodes;
    }

    public void setCallingCodes(List<String> callingCodes) {
        this.callingCodes = callingCodes;
    }

    public String getCapital() {
        return capital;
    }

    public void setCapital(String capital) {
        this.capital = capital;
    }

    public List<String> getAltSpellings() {
        return altSpellings;
    }

    public void setAltSpellings(List<String> altSpellings) {
        this.altSpellings = altSpellings;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getSubregion() {
        return subregion;
    }

    public void setSubregion(String subregion) {
        this.subregion = subregion;
    }

    public long getPopulation() {
        return population;
    }

    public void setPopulation(long population) {
        this.population = population;
    }

    public List<Integer> getLatlong() {
        return latlong;
    }

    public void setLatlong(List<Integer> latlong) {
        this.latlong = latlong;
    }

    public String getDemonym() {
        return demonym;
    }

    public void setDemonym(String demonym) {
        this.demonym = demonym;
    }

    public long getArea() {
        return area;
    }

    public void setArea(long area) {
        this.area = area;
    }

    public float getGini() {
        return gini;
    }

    public void setGini(float gini) {
        this.gini = gini;
    }

    public List<String> getTimezones() {
        return timezones;
    }

    public void setTimezones(List<String> timezones) {
        this.timezones = timezones;
    }

    public List<String> getBorders() {
        return borders;
    }

    public void setBorders(List<String> borders) {
        this.borders = borders;
    }

    public String getNativeName() {
        return nativeName;
    }

    public void setNativeName(String nativeName) {
        this.nativeName = nativeName;
    }

    public String getNumericCode() {
        return numericCode;
    }

    public void setNumericCode(String numericCode) {
        this.numericCode = numericCode;
    }

    public List<Currency> getCurrencies() {
        return currencies;
    }

    public void setCurrencies(List<Currency> currencies) {
        this.currencies = currencies;
    }

    public List<Language> getLanguages() {
        return languages;
    }

    public void setLanguages(List<Language> languages) {
        this.languages = languages;
    }

    public Translations getTranslations() {
        return translations;
    }

    public void setTranslations(Translations translations) {
        this.translations = translations;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public List<RegionalBlock> getRegionalBlocs() {
        return regionalBlocs;
    }

    public void setRegionalBlocs(List<RegionalBlock> regionalBlocs) {
        this.regionalBlocs = regionalBlocs;
    }

    public String getCioc() {
        return cioc;
    }

    public void setCioc(String cioc) {
        this.cioc = cioc;
    }

    @Override
    public String toString(){
        return "{ name : "+name+", topLevelDomain : "+topLevelDomain+", alpha2Code : "+alpha2Code+
            ", alpha3Code : "+alpha3Code+", callingCodes : "+callingCodes+", capital : "+capital+
            ", altSpellings : "+ altSpellings+", region : "+region+", subregion : "+subregion+
            ", population : "+population+", latlong : "+latlong+", demonym : "+demonym+", area : "+area+
            ", gini : "+gini+", timezones : "+timezones+", borders : "+borders+", nativeName : "+nativeName+
            ", numericCode : "+ numericCode+", currencies : "+currencies+", languages : "+languages+
            ", translations : "+translations+", flag : "+flag+", regionalBlocs : "+regionalBlocs+", cioc : "+cioc+" }";
    }


}

@JsonIgnoreProperties(ignoreUnknown = true)
 class Currency {

    @JsonProperty("code")
    public String code;

    @JsonProperty("name")
    public String name;

    @JsonProperty("symbol")
    public String symbol;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    @Override
     public String toString(){
        return "{ code : "+code+", name : "+name+", symbol : "+symbol+"}";
    }

 }

@JsonIgnoreProperties(ignoreUnknown = true)
class Language {

    @JsonProperty("iso639_1")
    public String iso639_1;

    @JsonProperty("iso639_2")
    public String iso639_2;

    @JsonProperty("name")
    public String name;

    @JsonProperty("nativeName")
    public String nativeName;

    public String getIso639_1() {
        return iso639_1;
    }

    public void setIso639_1(String iso639_1) {
        this.iso639_1 = iso639_1;
    }

    public String getIso639_2() {
        return iso639_2;
    }

    public void setIso639_2(String iso639_2) {
        this.iso639_2 = iso639_2;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNativeName() {
        return nativeName;
    }

    public void setNativeName(String nativeName) {
        this.nativeName = nativeName;
    }

    @Override
    public String toString(){
        return "{ iso639_1 : "+iso639_1+", iso639_2 : "+iso639_2+", name : "+name+ ", nativeName : "+nativeName+"}";
    }

}
@JsonIgnoreProperties(ignoreUnknown = true)
class Translations{

    @JsonProperty("de")
    public String de;

    @JsonProperty("es")
    public String es;

    @JsonProperty("fr")
    public String fr;

    @JsonProperty("ja")
    public String ja;

    @JsonProperty("it")
    public String it;

    @JsonProperty("br")
    public String br;

    @JsonProperty("pt")
    public String pt;

    @JsonProperty("nl")
    public String nl;

    @JsonProperty("hr")
    public String hr;

    @JsonProperty("fa")
    public String fa;

    public String getDe() {
        return de;
    }

    public void setDe(String de) {
        this.de = de;
    }

    public String getEs() {
        return es;
    }

    public void setEs(String es) {
        this.es = es;
    }

    public String getFr() {
        return fr;
    }

    public void setFr(String fr) {
        this.fr = fr;
    }

    public String getJa() {
        return ja;
    }

    public void setJa(String ja) {
        this.ja = ja;
    }

    public String getIt() {
        return it;
    }

    public void setIt(String it) {
        this.it = it;
    }

    public String getBr() {
        return br;
    }

    public void setBr(String br) {
        this.br = br;
    }

    public String getPt() {
        return pt;
    }

    public void setPt(String pt) {
        this.pt = pt;
    }

    public String getNl() {
        return nl;
    }

    public void setNl(String nl) {
        this.nl = nl;
    }

    public String getHr() {
        return hr;
    }

    public void setHr(String hr) {
        this.hr = hr;
    }

    public String getFa() {
        return fa;
    }

    public void setFa(String fa) {
        this.fa = fa;
    }

    @Override
    public String toString(){
        return "{ de:"+de+", es:"+es+", fr:"+fr+", ja:"+ja+", it:"+it+", br:"+br+", pt:"+pt+", nl:"+nl+
            ", hr:"+hr+", fa:"+fa+"}";
    }
}

    class RegionalBlock{

        @JsonProperty("acronym")
        public String acronym;

        @JsonProperty("name")
        public String name;

        @JsonProperty("otherAcronyms")
        public String[] otherAcronyms;

        @JsonProperty("otherNames")
        public String[] otherNames;

        @Override
        public String toString(){
            return "{ acronym : "+acronym+", name : "+name+", otherAcronyms : "+ otherAcronyms+", otherNames : "+otherNames+" }";
        }

    }


